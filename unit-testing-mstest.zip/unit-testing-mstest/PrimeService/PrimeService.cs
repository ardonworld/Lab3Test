﻿using System;

namespace PrimeService
{
    public class Class1
    {
    }
}
